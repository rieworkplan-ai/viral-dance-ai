# Viral Dance AI — Android project

This is the Android wrapper source project for the Viral Dance AI web prototype.
It contains the working local upload/preview interface in `www/index.html`.

## Build an APK using Android Studio

### Requirements
- Android Studio (current stable release)
- Android SDK installed through Android Studio
- Node.js 20 or newer and npm
- Internet access for the first dependency install

### Steps (Windows, macOS, or Linux)

1. Extract this ZIP.
2. Open a terminal in the extracted `ViralDanceAI_Android_Project` folder.
3. Install JavaScript dependencies:

   ```bash
   npm install
   ```

4. Create the native Android project:

   ```bash
   npx cap add android
   ```

   If the `android` folder already exists, skip this step.

5. Sync the web app into Android:

   ```bash
   npx cap sync android
   ```

6. Open the project in Android Studio:

   ```bash
   npx cap open android
   ```

7. Wait for Gradle sync. In Android Studio select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

8. Android Studio will show a notification with the APK location. Usually it is:

   `android/app/build/outputs/apk/debug/app-debug.apk`

For a shareable release APK, configure signing in Android Studio using **Build > Generate Signed Bundle / APK**.

## Current functionality
- Select a dance video from device storage and preview it.
- Select a character image and preview it.
- Configure full-body / face replacement mode, aspect ratio, resolution, duration, identity lock, and background setting.
- Validate that both media files are selected before preparing the project.

## Important limitations
This is an Android app wrapper around the prototype UI, not a completed AI rendering service.
The current **Prepare AI generation** action only validates the selections and displays a project summary. It does not perform face replacement or full-body motion transfer.

To enable real generation, a secure backend and licensed/authorized AI inference service must be integrated. Do not put private API keys in the Android app. Use server-side authentication, upload handling, job status, and secure media storage.

Only upload dance footage and likenesses you own or have permission to use.
